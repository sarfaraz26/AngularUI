export class Author {
    authorId : number = 0
    authorName : string = ""
    age : number = 0
    address : string = ""
}
